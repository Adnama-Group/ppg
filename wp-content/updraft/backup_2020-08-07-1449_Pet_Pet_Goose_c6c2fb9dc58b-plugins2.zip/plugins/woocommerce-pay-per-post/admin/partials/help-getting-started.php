<div class="postbox wc-ppp-help-tab" id="wc-ppp-help-getting-started-tab">

    <h2 class="hndle"><?php esc_attr_e( 'Protecting a Post', 'wc_pay_per_post' ); ?></h2>
    <div class="inside">
        <?php include('getting-started.php'); ?>
    </div>

</div>