<?php // Silence is golden
/**
 * TODO Add warning message if WooCommerce is not Activated
 */