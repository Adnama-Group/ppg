<?php

namespace Stripe\Error\OAuth;

defined( 'ABSPATH' ) || die();

/**
 * InvalidClient is raised when authentication fails.
 */
class InvalidClient extends OAuthBase
{
}
