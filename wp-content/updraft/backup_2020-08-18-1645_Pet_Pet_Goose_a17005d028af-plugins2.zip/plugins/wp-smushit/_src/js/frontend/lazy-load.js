import lazySizes from 'lazysizes';
import 'lazysizes/plugins/native-loading/ls.native-loading';
