<?php

namespace Stripe\Error;

defined( 'ABSPATH' ) || die();

class Idempotency extends Base
{
}
