<?php

return array(
	'styles2010' => 'styles2010',
	'cache2010' => 'cache2010',
);